(function(){
  var btn=document.getElementById("top");
  if(btn){btn.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"});});}
  document.addEventListener("keydown",function(e){
    if(e.key==="Home"){window.scrollTo({top:0,behavior:"smooth"});}
    else if(e.key==="End"){window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"});}
    else if(e.key==="ArrowDown"){window.scrollBy({top:Math.round(innerHeight*0.9),behavior:"smooth"});e.preventDefault();}
    else if(e.key==="ArrowUp"){window.scrollBy({top:-Math.round(innerHeight*0.9),behavior:"smooth"});e.preventDefault();}
  });
})();